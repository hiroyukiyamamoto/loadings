multiplsrog_loading <- function(multiplsrog){
  multiplsrog <- multipls_loading(multiplsrog)
  return(multiplsrog)
}
