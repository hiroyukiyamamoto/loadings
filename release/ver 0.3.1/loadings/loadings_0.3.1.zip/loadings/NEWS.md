## version 0.3.1

- Updated in February 14th, 2023.
- Added one-sided kernel PCA.
- Some bug fixes (pca_loading.R, pls_rog.R, multipls_rog.R) and correction of full-width Greek letters (whhl.RData).

## version 0.2.1

- Updated in September 2nd, 2022.
- Added multiset PLS and multiset PLS-ROG.

## version 0.1.1

- Released in August 31th, 2021.

## version 0.1.0.9000

- Development version.
