rm(list=ls(all=TRUE))

library(loadings)

### PCA
data(fasting)
X <- fasting$X

pca <- prcomp(X, scale=TRUE)

pca <- pca_loading(pca)
pca$loading$R
pca$loading$p.value

### PLS
data(whhl)
X <- whhl$X
Y <- whhl$Y

pls <- pls_svd(X,Y)
# library(chemometrics)
# pls <- pls_eigen(X,Y,a=3)

pls <- pls_loading(pls)
pls$loading$R
pls$loading$p.value

### PLS-ROG
data(whhl)
X <- whhl$X
Y <- whhl$Y
D <- whhl$D

plsrog <- pls_rog(X,Y,D,0.999)

plsrog <- pls_loading(plsrog)
plsrog$loading$R
plsrog$loading$p.value

### OS-PCA
data(turnover)
X <- turnover$X
D <- turnover$D

ospca <- os_pca(X,D,0.999)

ospca <- ospca_loading(ospca)
ospca$loading$R
ospca$loading$p.value

### OS-PCA2
data(greentea)
X <- greentea$X
Y <- greentea$Y
D <- greentea$D
M <- greentea$M

ospca <- os_pca(X,D,0.999,M)

ospca <- ospca_loading(ospca)
ospca$loading$R
ospca$loading$p.value

