ospca_loading <- function(ospca){
  
  ospca_loading <- pls_loading

}


