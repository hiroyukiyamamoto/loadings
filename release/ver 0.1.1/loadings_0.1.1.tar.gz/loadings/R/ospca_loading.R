ospca_loading <- function(ospca){

  ospca_loading <- pls_loading(ospca)

  return(ospca_loading)

}


